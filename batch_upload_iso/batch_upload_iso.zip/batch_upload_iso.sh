#!/bin/bash

#Purpose：一键上传ISO文件到指定存储
#Author:zyc
#Time:20160922
#Version:1.0
#Design:主要解决2个问题：1.从办公网上传ISO太慢了(2MB/s的均速) 2.得一个个手动上传
#Usage:1.vmp前台添加存储  2.后台cd到存储所在的iso目录  3.执行该脚本

LOG_FILE_Client="/sf/log/today/LOG_xml_to_csv.log"

#定义日志函数
zyc_log()
{
	LOG_MSG="$1"
	echo "[`date +'%Y-%m-%d %H:%M:%S'`]--${LOG_MSG}" >> ${LOG_FILE_Client}
}

zyc_log "Now,we will upload Windows desktop ISO."
#上传Windows desktop类的ISO。主要为中文版
wget -c --ftp-user=vtt --ftp-password=123 ftp://200.200.164.111/01-ISO/Windows/01-winXP/YLMF_GHOST_XP_SP3_2015_02.iso
wget -c --ftp-user=vtt --ftp-password=123 ftp://200.200.164.111/01-ISO/Windows/01-winXP/FQHY_GHOST_WIN7_SP1_X64_V2014_11.iso
wget -c --ftp-user=vtt --ftp-password=123 ftp://200.200.164.111/01-ISO/Windows/02-win7/cn_windows_7_ultimate_x86_dvd_x15-65907.iso
wget -c --ftp-user=vtt --ftp-password=123 ftp://200.200.164.111/01-ISO/Windows/02-win7/cn_windows_7_ultimate_x64_dvd_x15-66043.iso
wget -c --ftp-user=vtt --ftp-password=123 ftp://200.200.164.111/01-ISO/Windows/03-win8/cn_windows_8_1_enterprise_x86_dvd_2972257.iso
wget -c --ftp-user=vtt --ftp-password=123 ftp://200.200.164.111/01-ISO/Windows/03-win8/cn_windows_8_1_enterprise_x64_dvd_2971863.iso
wget -c --ftp-user=vtt --ftp-password=123 ftp://200.200.164.111/01-ISO/Windows/04-win10/Windows10_x86_ch.iso
wget -c --ftp-user=vtt --ftp-password=123 ftp://200.200.164.111/01-ISO/Windows/04-win10/cn_windows_10_multiple_editions_x64_dvd_6848463.iso

zyc_log "Upload Windows desktop ISO finish.Next,upload Windows server ISO."

#上传Windows Server类的ISO。主要为中文版
wget -c --ftp-user=vtt --ftp-password=123 ftp://200.200.164.111/01-ISO/Windows/04-win2003/win_2003_SP2_Enterprise_CN.iso
wget -c --ftp-user=vtt --ftp-password=123 ftp://200.200.164.111/01-ISO/Windows/04-win2003/cn_win_srv_2003_r2_standard_x64_with_sp2_vl_cd1_X13-47363.iso
wget -c --ftp-user=vtt --ftp-password=123 ftp://200.200.164.111/01-ISO/Windows/04-win2003/cn_win_srv_2003_r2_standard_x64_with_sp2_vl_cd2_X13-28819.iso
wget -c --ftp-user=vtt --ftp-password=123 ftp://200.200.164.111/01-ISO/Windows/06-win2008/WindowsServer2008_x86.iso
wget -c --ftp-user=vtt --ftp-password=123 ftp://200.200.164.111/01-ISO/Windows/06-win2008/cn_windows_server_2008_r2_standard_enterprise_sp1_vl_build_x64.iso
wget -c --ftp-user=vtt --ftp-password=123 ftp://200.200.164.111/01-ISO/Windows/07-win2012/cn_windows_2012_r2_x64__NB4WH-BBBYV-3MPPC-9RCMV-46XCB.iso
zyc_log "Upload Windows server ISO finish."

exit 0